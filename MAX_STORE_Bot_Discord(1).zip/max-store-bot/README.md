# MAX STORE 1 REAL — bot de vendas Discord

## Recursos incluídos
- Comandos slash para cadastrar/listar produtos e publicar painel.
- Botão de compra com verificação simples.
- Criação de pedido com instruções Pix.
- Confirmação **manual** do Pix por administrador.
- Registro da venda no canal configurado e entrega por mensagem privada após confirmação.

## Importante sobre Pix
Esta versão **não verifica automaticamente** se o Pix foi pago. O administrador precisa conferir o recebimento no banco e usar `/venda-confirmar pedido:ID`. Para confirmação automática é necessário integrar um provedor de pagamento/API Pix confiável com credenciais privadas e webhook.

## Configuração
1. Crie uma aplicação/bot no Discord Developer Portal e convide-o ao servidor com permissões para ver/enviar mensagens e usar comandos de aplicação.
2. Configure estas variáveis na hospedagem (não coloque segredos no GitHub):
   - `DISCORD_TOKEN`: token do bot
   - `CLIENT_ID`: ID da aplicação Discord
   - `GUILD_ID`: ID do servidor onde os comandos serão registrados
   - `SALES_CHANNEL_ID`: ID do canal de registros de vendas
   - `PIX_KEY`: chave Pix da loja
   - `PIX_NAME`: nome do recebedor
   - `STORE_NAME`: nome exibido, opcional
3. Instale com `npm install` e inicie com `npm start` ou `npm run start`.
4. No Discord, use `/produto-adicionar` para cada produto e depois `/painel-vendas`.
5. Quando receber o Pix no banco, confirme com `/venda-confirmar` usando o ID do pedido.

## Limitações desta versão
- Produtos ficam em memória e precisam ser cadastrados novamente após reiniciar.
- Os pedidos são guardados num JSON local; hospedagens efêmeras podem apagar os dados ao reiniciar.
- A verificação é apenas uma confirmação digitada, não uma verificação de identidade.
- A confirmação do pagamento é manual, não automática.
